require("dotenv").config();
var http=require("http");
var fs=require("fs")
var path=require("path")
var url=require("url");
var querystring=require("querystring");

var empArr=[{
    "empId": 101,
    "empName": "asha",
    "salary": 1001,
    "deptId": "D1"
}, {
    "empId": 102,
    "empName": "Gaurav",
    "salary": 2000,
    "deptId": "D1"
}, {
    "empId": 103,
    "empName": "Karan",
    "salary": 2000,
    "deptId": "D2"
},
{
    "empId": 104,
    "empName": "Kishan",
    "salary": 3000,
    "deptId": "D1"
},
{
    "empId": 105,
    "empName": "Keshav",
    "salary": 3500,
    "deptId": "D2"
},
{
    "empId": 106,
    "empName": "Pran",
    "salary": 4000
},
{
    "empId": 107,
    "empName": "Saurav",
    "salary": 3800
}
]

const PORT=process.env.PORT || 3000;
const HOST=process.env.HOST || "localhost";

app=http.createServer((req,res)=>{
    console.log(req.url)
    var urlObj=url.parse(req.url);
    console.log(urlObj)
    if(req.method =="GET")
    {
        if(req.url =="/welcome")
        {
            res.write("Welcome to the server");
            res.write("Thank u for contacting the server")
            res.end();
        }
        else 
        if(req.url == "/getEmpJsonData")
        {
            var mydata="";
            var fileUrl=path.join(__dirname,"empData.json")
            var reader=fs.createReadStream(fileUrl)
            reader.on("data",(chunks)=>{
                mydata+=chunks;
            })
            reader.on("end",()=>{
                myDataInJson=JSON.parse(mydata);
                console.log(myDataInJson);
                var empArr1=myDataInJson.employees;
                var sumOfsalary=0;
                empArr1.forEach(item=>{
                    sumOfsalary+=item.salary;
                })
                res.write("Sum of salary of all the employees"+sumOfsalary);
                res.end();
            })
            reader.on("error",(err)=>{
                res.writeHead(401);
                res.write("Error reading the file");
                res.end();
            })
        }
        else
        if(req.url =="/employees")
        {
            // give  a json array as a response
            // stringify the json
            res.setHeader={"Content-type":"text/json"}
            res.write(JSON.stringify(empArr));
            res.end()
         
        }
        else
        if(req.url == "/aboutus")
        {
            var str1="Indium Software received accreditation of ISO 27001:2013 certification, (Global best practice specification of Information Security Management Systems (ISMS)). This certification is applicable to Information Security Management pertaining to Development & Testing services across Digital and QA."
            res.writeHead(201,"Information sent",{"Content-type":"text/text"})
            res.write(str1);
            res.end()
        }
        else
        if(req.url == "/products")
        {
            // send a file as a response
            var fileUrl=path.join(__dirname,"public","products.html")
            fs.readFile(fileUrl,(err,data)=>{
                if(err)
                {
                    res.writeHead(401,"File not found");
                    res.write("Products File not found");
                    res.end();
                }
                else
                {
                    res.write(data);
                    res.end();
                }
            })

        }
        else
        if(req.url == "/feedback")
        {
            // send html response as a string
            var str1=`
            <html>
                <body>
                    <h1> Feedback</h1>
                    <form>
                        Enter the feedback:
                        <textarea rows="5" ></textarea> 
                        <br/>
                        <input type="submit" value="Share Feedback" />
                    </form>
                </body>
            </html>
            `
            res.write(str1);
            res.end()
        }
        else
        if(req.url == "/image")
        {
            // send an image as a response
            // readFile -- 
            // createReadStream  -- file size is big
            var fileUrl=path.join(__dirname,"public","flower.jpg")
            var reader=fs.createReadStream(fileUrl)
            reader.on("data",(chunks)=>{
                res.write(chunks);
            })
            reader.on("end",()=>{
                res.end();
            })
            reader.on("error",(err)=>{
                res.writeHead(401);
                res.write("Error reading the file");
                res.end();
            })


        }
        else
        if(urlObj.pathname == "/storeProductDetails")
        {
            var myQueryString=urlObj.query;
            var myQueryObj=querystring.parse(myQueryString);
            res.write("Product details saved with product name"+myQueryObj.txtProductName)
            res.end();
        }
        else
        {
            res.write("Thank u for the get requests");
            res.end()
        }
    }
    else
    if(req.method == "POST")
    {
        // data is coming as part of body request 
        // request -- read stream
        if(req.url == "/employees")
        {
            var myData=""
            req.on("data",(chunks)=>{myData+=chunks;})
            req.on("end",()=>{
                var parsedMyData=JSON.parse(myData);
                empArr.push(parsedMyData);
                res.write("Employee details saved with employeeId "+parsedMyData.empId)
                res.end();
            })
        }
    }
    else
    {
        res.write("Welcome to the server");
        res.write("Thank u for contacting the server")
        res.end();
    }
})

app.listen(PORT,HOST,(err)=>{
    if(!err)
    {
        console.log(`Server is running at http://localhost:${PORT}`)
    }
})
// json; file,html file, image,string,string with html contents
// post request; get request as query string; put delete
// server --> read from the req stream; write into the response stream
//client  --> read from the res stream; write into the req stream

// write stream :write(chunk)--> write a chunk of info; end()--> denote the end of write stream

//read stream : events to handle --> data event triggered -- chunk is ready and end event triggered -->after completing the chunks