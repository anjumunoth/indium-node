console.log("Process id"+process.pid);

console.log("Command line args",process.argv)
var sum1=0;
for(let i=2;i<process.argv.length;i++)
{
    sum1+=parseInt(process.argv[i]);
}
console.log("Sum of the arguments",sum1)