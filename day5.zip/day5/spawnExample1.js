var childProcess=require("child_process");

var child=childProcess.spawn("node",["readFileExample.js"])
child.on("exit",(code)=>{
    console.log("Child process exited with code "+code);

})
// child.stdin(write stream), child.stdout,child.stderr
child.stderr.on("data",(err)=>{
    console.log(err.toString())
})
child.stdout.on("data",(data)=>{
    console.log("child stdout",data.toString());
})
child.stdin.write("Welcome to the training on node")
child.stdin.write(JSON.stringify({empId:101,empName:"sara"}))
child.stdin.end();