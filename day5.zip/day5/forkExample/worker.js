var fs=require("fs")
var writer=fs.createWriteStream("text2.txt",{flags:"a"})
process.on("message",(msg)=>{
    if(msg=="Create")
    {
        process.send("File created")
    }
    else
    if(msg == "Append")
    {
        writer.write("Got new message from master at "+(new Date().toString()));
        process.send("File appended")
    }
    else
    if(msg== "Close")
    {
        writer.end()
        process.send("File closed")
        process.exit()
    }
})