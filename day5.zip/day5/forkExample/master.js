var {fork}=require("child_process");
const { clearInterval } = require("timers");
var child=fork("worker.js")
child.send("Create")
child.on("message",(msg)=>{
    console.log("Message from the child",msg.toString());
})
i=0;
clearTimeOutId=setInterval(()=>{
    child.send("Append");
    i++;
    if(i==10)
    {
        clearInterval(clearTimeOutId);
        child.send("Close");
    }
},1000)

child.on("exit",(exitcode)=>{
    console.log("Child exited with exit code"+exitcode)
})


