var {spawn,spawnSync}=require("child_process");
var path=require("path")
var child=spawn("mkdir",["temp"],{shell:true})
spawn("cd",["temp"],{shell:true})
spawnSync("npm init",["-y"],{shell:true,cwd:path.join(__dirname,"temp")})
child1=spawn("npm",["install","--save","cors","express"],{shell:true,cwd:path.join(__dirname,"temp")})
 
child.on("error",(err)=>{
    console.log("Error",err)
})

child1.stdout.on("data",(data)=>{
    console.log("output of module installation",data.toString())
})

