const {execFile} =require("child_process");
execFile("node",["--version"],(err,stdout,stderr)=>{
    if(err)
    {
        console.log("Err in execFile",err)
    }
    else
    {
        console.log(stdout);
    }
})