var {exec} =require("child_process");
const path=require("path")

var child1=exec("node worker.js",{cwd:path.join(__dirname)},(err,stdout,stderr)=>{
    if(!err)
        console.log("data from the worker",stdout)
    else
        console.log(err);
})