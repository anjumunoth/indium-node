var fs=require("fs")
console.log("hello");
var writer=fs.createWriteStream("text1.txt")
    writer.write("hello");
    writer.write("welcome to the exec example");
    writer.end();

console.log("Successfully written into the file");