//imports
require("dotenv").config()

var express=require("express");
var path=require("path")
var fs=require("fs")
var bodyParser=require("body-parser")

//instatiation
app=express()
const PORT=process.env.PORT ||3000
// configuration

app.set("port",PORT)

//middleware
app.use(express.static(path.join(__dirname,"public")))
//app.use(bodyParser.json())
// convert the req  body into the json format
app.use(express.json())
app.use(express.urlencoded({extended:false}))
//routes
app.get("/",(req,res)=>{
    res.send("Welcome to the server")

})

app.get("/user/:username",(req,res)=>{
    res.send("Welcome "+ req.params.username);
})

app.get("/books",(req,res)=>{
    var book={bookId:"B101",bookName:"alchemist", author:"Paul Coelho"}
    res.json(book);
})

app.get("/getCurrentTime",(req,response)=>{
    const myValue=new Date().toDateString();
    res.send(myValue);
    
    
})

app.get("/users/:username",(req,res)=>{
    if(req.params.username !== "sara")
    {
        res.status(404).send("User not found");
        return;
    }
    res.sendStatus(201)
    res.send("Welcome admin")// ignored
})

app.get("/getjsondata",(req,res)=>{
    var fileUrl=path.join(__dirname,"empData.json");
    res.sendFile(fileUrl,(err)=>{
        if(err)
            console.log(err)
        else
            console.log("file sent successfully")
    })

})

app.get("/downloadPdf",(req,res)=>{
    var fileUrl=path.join(__dirname,"public","Node_Contents.pdf")
    res.download(fileUrl,(err)=>{
        if(err)
            res.send("Error downloading the file")
        else
            console.log("File downloading successfully")
    })
})

app.get("/home",(req,res)=>{
    var fileUrl = path.join(__dirname,"public","index.html");
    res.sendFile(fileUrl, (err)=>{
      if(err){
        res.send("error");
      }else{
       console.log("file sent success");
      }
    })
  });
app.get("/storeProductInfo",(req,res)=>{
    var fileUrl=path.join(__dirname,"public","products.html");
    res.sendFile(fileUrl,(err)=>{
        if(err)
            console.log(err)
        else
            console.log("file sent successfully")
    })
})

app.get("/emp",(req,res)=>{
    var fileUrl=path.join(__dirname,"empData.json");
    var myData="";
    var reader=fs.createReadStream(fileUrl)
    reader.on("data",(chunk)=>{myData+=chunk})
    reader.on("end",()=>{
        myData=JSON.parse(myData);
        res.json(myData.employees)
    })
    reader.on("error",(err)=>{
        res.status(401).send("Error reading the file")
    })
})
/* app.get("/style.css",(req,res)=>{
    var fileUrl=path.join(__dirname,"public","style.css");
    res.sendFile(fileUrl,(err)=>{
        if(err)
            console.log(err)
        else
            console.log("file sent successfully")
    })

})

 */ 

app.post("/confirmProductInfo",(req,res)=>{
    // get the data from request body section
    console.log(req.body);
    // store it and send the response back
    res.send("Saved the product details"+req.body.productName)
})
empArr=[]
app.get("/employees",(req,res)=>{
    res.json(empArr);
})
app.post("/employees",(req,res)=>{
    empArr.push(req.body);
    console.log(empArr);
    res.status(201).send("Employee details saved");

})
app.put("/employees",(req,res)=>{
    // get the data from request body section
    console.log(req.body);
    var pos=empArr.findIndex(item => item.empId == req.body.empId)
    if(pos >=0)
    {
        empArr.splice(pos,1,req.body);
        res.send("Saved the employee details"+req.body.empId)        
    }
    else
    {   
    // store it and send the response back
    res.send("Emp not found with empId"+req.body.empId)
    }
})



// error handling

//server listen
app.listen(PORT,(err)=>{
    if(!err)
    {
        console.log("Server is running at "+PORT)
    }

})