var eventsEmitter=require("events");
var myEvent=new eventsEmitter.EventEmitter()

// custom events  -- subscribe to an event, handler,trigger the event

myEvent.on("welcome",()=>{
    console.log("Welcome to nodejs training")
})

myEvent.emit("welcome");
var empArr,logArr;
myEvent.once("initialiseData",()=>{
    empArr=[],logArr=[]

})

myEvent.on("addEmp",(emp)=>{
    empArr.push(emp)
})

myEvent.on("updateEmp",(emp) =>{
    var pos=empArr.findIndex(item => item.empId ==emp.empId)
    if(pos >=0)
    {
        empArr.splice(pos,1,emp)
    }
    else
    {
        console.log("Employee Id: "+emp.empId+" does not exists")
    }
})

myEvent.on("deleteEmp",(empId)=>{
    var pos = empArr.findIndex((item) => item.empId == empId);
     if (pos > 0) {
        empArr.splice(pos, 1);
    } else {
        console.log('Emp Id'+empId+' doesn\'t exist');
    }

})

myEvent.emit("initialiseData");//execute the eventhandler
myEvent.emit("addEmp",{empId:101,empName:"sara",salary:1234});
myEvent.emit("addEmp",{empId:102,empName:"tara",salary:12234});
myEvent.emit("addEmp",{empId:103,empName:"lara",salary:41234});
myEvent.emit("addEmp",{empId:104,empName:"saurav",salary:31234});

myEvent.emit("updateEmp",{empId:101,empName:"ganesh",salary:7899});
myEvent.emit("updateEmp",{empId:777,empName:"ganesh",salary:7899});

myEvent.emit("deleteEmp",102);//empdetails deleted
myEvent.emit("deleteEmp",555);// emp id does not exists

console.log(empArr)
// have multiple event handlers for the same event
myEvent.on("addEmployees",(list1)=>{
    list1.forEach(element => {
        empArr.push(element);
    });

})
myEvent.on("addEmployees",(list1)=>{
    var str1=`${list1.length} elements added to the employee arr`
    logArr.push(str1)
})

myEvent.emit("addEmployees",[{ empId: 105, empName: 'sita', salary: 2000 },
{ empId: 106, empName: 'gita', salary: 2000 },])

myEvent.emit("addEmployees",[{ empId: 107, empName: 'sita', salary: 2000 }])
// 2event handlers will get executed
console.log(empArr)
console.log(logArr)
myEvent.emit("initialiseData")// ignored
console.log(empArr);//[]
console.log(logArr);//[]
function addDataEventHandler(p1){
    console.log("data added "+p1)
}
function addDataEventHandler2(p1)
{
    logArr.push(`${p1} was added`)
}
myEvent.on("addData",addDataEventHandler)
myEvent.on("addData",addDataEventHandler2)
myEvent.emit("addData",1)
myEvent.removeListener("addData",addDataEventHandler)
myEvent.emit("addData",2)//addDataEventHandler2
console.log(logArr)

myEvent.removeAllListeners("addEmployees")
myEvent.emit("addEmployees",[{ empId: 108, empName: 'sita', salary: 2000 }])
console.log(empArr)
console.log(logArr)



