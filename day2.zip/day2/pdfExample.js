var fs = require("fs");
var pdfreader=require("pdfreader");
fs.readFile("../Node_Contents.pdf", (err, pdfBuffer) => {
  // pdfBuffer contains the file content
  new pdfreader.PdfReader().parseBuffer(pdfBuffer, function (err, item) {
    if (err) console.log(err);
    else if (!item) console.log("Not an item");
    else if (item.text) console.log(item.text);
  });
});