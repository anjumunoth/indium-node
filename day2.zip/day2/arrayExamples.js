var empArr=[ { empId: 101, empName: 'ganesh', salary: 7899 },
{ empId: 102, empName: 'tara', salary: 2000 },
{ empId: 103, empName: 'lara', salary: 2000 },
{ empId: 104, empName: 'saurav', salary: 31234 }]

// findIndex -- first occurence 
var pos=empArr.findIndex((item)=>{
    if(item.empId == 777)
        return true;

})
console.log(pos);

// 1st iteration : {empId:101} ---> item -- execute the function  --false
// 2nd iteration : {empId:102} --->item -- execute the function -- false
// 3rd iteration -- {empId: 103}  true ; a. return the position 2;b. break the loop

// pos =-1 when none of the elements satisfy the predicate function

// get the pos of the emp whose salary is 2000
var empDetail = empArr.find((item)=>{
    if(item.salary==2000)
        return true
})
console.log(empDetail);//{ empId: 102, empName: 'tara', salary: 2000 }


var empDetailArr = empArr.filter((item)=>{
    if(item.salary==2000)
        return true
})
console.log(empDetailArr);//[{ empId: 102, empName: 'tara', salary: 2000 },{ empId: 103, empName: 'lara', salary: 2000 },]

var salaryArr=empArr.map(item=>{
    if(item.salary >=5000)
        return item.empId;
})
console.log(salaryArr);//[101,ud,ud,104]

// map -- resultant arr ; target arr -- same size

// filter  -- array 
var empFilteredArr=empArr.filter(item=>{
    if(item.salary >=500000)
        return item
})
console.log(empFilteredArr);// []

var empFilteredArr=empArr.find(item=>{
    if(item.salary >=500000)
        return item
})
console.log(empFilteredArr);// ud

var arr1=[10,20,30,40,50,60]
//arr1.splice(3,1);//delete 1 element from the 3rd pos;[10,20,30,50,60]
arr1
