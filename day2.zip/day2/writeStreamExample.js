var fs=require("fs")

var writer=fs.createWriteStream("text1.txt")
writer.write("Today is a beautiful day")
writer.write("Today is the second day of the training")
writer.end();// 
