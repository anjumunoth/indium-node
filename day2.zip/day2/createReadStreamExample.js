// stream
var fs=require("fs")

// 1kb=1024 bytes
//chunk size :1024kb : 1024*1024 bytes 

var reader=fs.createReadStream("rest.json",{highWaterMark:1024*1024});
var myData="",chunkCtr=0;
reader.on("data",(chunk)=>{
    chunkCtr++;
    myData+=chunk;
})
reader.on("end",()=>{
    console.log("ChunkCtr "+chunkCtr);//chunksize: 1024kb --2 chunks ; chunk1 -- 1024kb; chunk2 =960kb
})
reader.on("error",(err)=>{
    console.log("Error reading the file",err)
})



// chunk size-- default size: 64kb; 30 chunks 64kb; 31st chunk <=64kb
