var fs=require("fs");
try
{
    var dataContent=fs.readFileSync("../text10.txt")
    console.log("Contents of the file",dataContent.toString())
}
catch(err)
{
    console.log("Error reading the file")
}
finally
{
    console.log("Bye")
}

// arrow functions are anonymous functions


// readFile, readFileSync
/*async read -- worker thread in the internal thread pool 
single main thread -- free to handle the other op
readFileSync -- single server -- do the read -- block the other op(req,res);

small file , get the contents and proceed the next task
readFileSync -- avoided
*/